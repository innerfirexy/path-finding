#!/bin/sh

echo $1
